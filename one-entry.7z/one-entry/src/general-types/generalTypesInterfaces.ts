interface IGeneralTypes {
    getAllTypes():Promise<any>
}



export {
    IGeneralTypes
}