interface IMenus {
    getMenusByMarker(marker:string):Promise<any>
}

export {
    IMenus
}