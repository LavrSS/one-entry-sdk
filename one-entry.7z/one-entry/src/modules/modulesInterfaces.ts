interface IModules {
    getAllModules():Promise<any>
}

export {
    IModules
}