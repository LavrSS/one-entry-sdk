interface ILocales {
    getLocales():Promise<any>
}

export {
    ILocales
}