interface IAdmins {
    getAdminsInfo():Promise<any>
}



export {
    IAdmins
}